git clone https://github.com/JREAM/config-ubuntu.git
cd config-ubuntu
git submodule init && git submodule update

or

cd config-ubuntu
git submodule init && git submodule update
