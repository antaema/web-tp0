# TODO

- Ubuntu 16.10
    - new users have no ~/.config
    - .composer globals install to: `~/.config/composer` (not dot)
- Ubuntu 16.04
    - if root (not recoomended) it goes into /root/.config/composer
    - .composer globals install to `~/.composer/` (dot)


I want aliases for this to be simpler:

find str in file:
find str in Anyfiles:
find by file name
find by dir name
find by ext name
find any by regex

Pipe things

rmByName, name, need recursive flag (incl ext?)
rmByExt - dir, always recursive

Pipe
